# Lucid Office frontend prototype

The standalone frontend design approved for Lucid Office. It is intentionally disconnected from the existing application, server, shared protocol, and media harness. Integration is a separate task.

## Preview

Open `frontend-prototype/index.html` directly in a browser. No dependencies, build step, environment variables, or credentials are required.

For a consistent local browser origin, run this from the repository root:

```sh
python3 -m http.server 5173 --directory frontend-prototype
```

Then visit `http://localhost:5173`. On Windows, `py -m http.server 5173 --directory frontend-prototype` is another option.

## Included interactions

- One top navigation bar: Office, People, Desk notes, Meeting notes, and Reminders.
- Floating, closable panels on the right, with the selected section highlighted.
- A pixel office with click-to-walk pathfinding, keyboard movement, named desks, and hover feedback. Focus the office to use WASD or arrow keys.
- A floating bottom dock for simulated microphone, sound, availability, desk notes, and leaving the office.
- Recipient-specific desk sticky notes, replies, unread counts, and received/sent views. Click a desk or use the dock to compose a note.
- A simulated meeting-room and AI-consent flow that produces sample meeting notes.
- Personal reminders and local due notifications.

## Prototype boundaries

Cameron is the demo user; the other people are fixtures. Movement is local. Microphone and sound controls do not capture or play audio. Meeting privacy and AI processing are simulated. Desk notes are not delivered to another person.

Desk notes, meeting-note drafts, and reminders use browser `localStorage` under `lucid.prototype.*`. Storage is local to that browser and origin. There are no network requests, external assets, SDKs, or backend connections; the office and avatars are drawn with canvas, and icons are inline SVG.

## Integration handoff

All prototype HTML, CSS, and JavaScript live in `index.html`. It can be used as a visual and interaction reference without changing the existing server.

When integration begins, replace demo identity and fixture state, local movement, simulated media/AI behavior, and browser-only persistence with the application's corresponding services. The prototype artwork, coordinate system, desk assignments, and collision geometry were designed independently of the server map contract and must be reconciled during integration. Existing labels such as private meeting audio describe the intended experience, not implemented media isolation in this file.

This addition does not change root npm scripts, dependencies, server routes, Docker configuration, or the existing media harness.

## Verification

JavaScript syntax and local canvas/state checks passed for navigation, panel toggling, desk-note routing/replies and persistence, unread counts, audio-status labels, and movement through the meeting room. A full browser/device acceptance pass remains to be completed; these checks do not verify multiplayer, real media, or backend integration.
